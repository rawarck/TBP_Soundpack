-- TBP_soundpack: plays sprite + sound clips when a keyword is typed in guild chat,
-- or when someone presses a clip button (hidden addon message to the guild).
-- Clip data lives in Clips.lua, which the generator writes.

local ADDON = "TBP_soundpack"
local PREFIX = "TBP"
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\media\\"

local clips = TBP_CLIPS or {}
local byKeyword, byId = {}, {}
for _, c in ipairs(clips) do
  byKeyword[c.keyword] = c
  byId[c.id] = c
end

local db -- SavedVariables (may not persist on Forever; defaults always work)
local defaults = { point = { "CENTER", "CENTER", 0, 120 }, scale = 1, muted = false }

local function print_(msg)
  DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99TBP|r " .. tostring(msg))
end

-- True if a value is a Midnight-style "secret" we must not inspect.
local function isSecret(v)
  return issecretvalue and issecretvalue(v) or false
end

----------------------------------------------------------------------
-- Display frame
----------------------------------------------------------------------
local display = CreateFrame("Frame", "TBP_SoundpackDisplay", UIParent)
display:SetSize(256, 256)
display:SetFrameStrata("HIGH")
display:SetClampedToScreen(true)
display:SetMovable(true)
display:Hide()

local tex = display:CreateTexture(nil, "ARTWORK")
tex:SetAllPoints()

local unlockBg = display:CreateTexture(nil, "BACKGROUND")
unlockBg:SetAllPoints()
unlockBg:SetColorTexture(0.2, 0.6, 1, 0.35)
unlockBg:Hide()

local unlockLabel = display:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
unlockLabel:SetPoint("CENTER")
unlockLabel:SetText("TBP - drag me\n/tbp lock when done")
unlockLabel:Hide()

display:RegisterForDrag("LeftButton")
display:SetScript("OnDragStart", display.StartMoving)
display:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  if db then db.point = { p, rp, x, y } end
end)

local function applyPosition()
  local pt = (db and db.point) or defaults.point
  display:ClearAllPoints()
  display:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
  display:SetScale((db and db.scale) or 1)
end

local unlocked = false
local playing -- { clip, elapsed, lastFrame }
local soundHandle

local function stop()
  playing = nil
  if not unlocked then display:Hide() end
  tex:SetTexture(nil)
end

local function showFrame(clip, i)
  local sheetIndex = math.floor(i / clip.perSheet) + 1
  local idx = i % clip.perSheet
  local col = idx % clip.cols
  local row = math.floor(idx / clip.cols)
  tex:SetTexture(MEDIA .. clip.sheets[sheetIndex])
  local l = col * clip.frameW / clip.sheetW
  local r = (col + 1) * clip.frameW / clip.sheetW
  local t = row * clip.frameH / clip.sheetH
  local b = (row + 1) * clip.frameH / clip.sheetH
  tex:SetTexCoord(l, r, t, b)
end

display:SetScript("OnUpdate", function(_, elapsed)
  if not playing then return end
  playing.elapsed = playing.elapsed + elapsed
  local clip = playing.clip
  local i = math.floor(playing.elapsed * clip.fps)
  if i >= clip.frames then
    stop()
    return
  end
  if i ~= playing.lastFrame then
    playing.lastFrame = i
    showFrame(clip, i)
  end
end)

local function play(clip)
  if not clip or (db and db.muted) then return end
  if soundHandle then StopSound(soundHandle) end
  display:SetSize(clip.frameW, clip.frameH)
  playing = { clip = clip, elapsed = 0, lastFrame = 0 }
  showFrame(clip, 0)
  display:Show()
  if clip.sound then
    local _, handle = PlaySoundFile(MEDIA .. clip.sound, "Master")
    soundHandle = handle
  end
end

----------------------------------------------------------------------
-- Triggers
----------------------------------------------------------------------
local function normalize(msg)
  return strtrim(msg):gsub("%s+", " "):lower()
end

local function broadcast(clip)
  if IsInGuild() then
    C_ChatInfo.SendAddonMessage(PREFIX, "P:" .. clip.id, "GUILD")
  else
    print_("You're not in a guild - playing locally only.")
    play(clip)
  end
end

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("CHAT_MSG_GUILD")
events:RegisterEvent("CHAT_MSG_ADDON")

local handlers = {}

function handlers.ADDON_LOADED(name)
  if name ~= ADDON then return end
  TBP_soundpackDB = TBP_soundpackDB or {}
  db = TBP_soundpackDB
  for k, v in pairs(defaults) do
    if db[k] == nil then db[k] = v end
  end
  applyPosition()
  C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
end

function handlers.CHAT_MSG_GUILD(msg)
  if type(msg) ~= "string" or isSecret(msg) then return end
  play(byKeyword[normalize(msg)])
end

function handlers.CHAT_MSG_ADDON(prefix, text, channel)
  if isSecret(prefix) or prefix ~= PREFIX or channel ~= "GUILD" then return end
  if isSecret(text) or type(text) ~= "string" then return end
  local id = text:match("^P:(.+)$")
  if id then play(byId[id]) end
end

events:SetScript("OnEvent", function(_, event, ...)
  local h = handlers[event]
  if h then
    -- Chat data can be restricted in instances/combat on Forever; never throw.
    local ok, err = pcall(h, ...)
    if not ok and TBP_DEBUG then print_(err) end
  end
end)

----------------------------------------------------------------------
-- Button panel (hidden broadcast)
----------------------------------------------------------------------
local panel
local function buildPanel()
  panel = CreateFrame("Frame", "TBP_SoundpackPanel", UIParent)
  panel:SetFrameStrata("DIALOG")
  panel:SetPoint("CENTER", UIParent, "CENTER", 300, 0)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  panel:SetClampedToScreen(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart", panel.StartMoving)
  panel:SetScript("OnDragStop", panel.StopMovingOrSizing)

  local bg = panel:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetColorTexture(0, 0, 0, 0.75)

  local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  title:SetPoint("TOP", 0, -8)
  title:SetText("TBP Soundpack")

  local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)

  local y = -30
  for _, clip in ipairs(clips) do
    local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    b:SetSize(160, 22)
    b:SetPoint("TOP", 0, y)
    b:SetText(clip.keyword)
    b:SetScript("OnClick", function() broadcast(clip) end)
    y = y - 26
  end
  if #clips == 0 then
    local none = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    none:SetPoint("TOP", 0, y)
    none:SetText("No clips yet")
    y = y - 20
  end
  panel:SetSize(180, -y + 8)
end

local function togglePanel()
  if not panel then buildPanel() return end
  panel:SetShown(not panel:IsShown())
end

----------------------------------------------------------------------
-- Slash commands
----------------------------------------------------------------------
SLASH_TBPSOUNDPACK1 = "/tbp"
SlashCmdList.TBPSOUNDPACK = function(input)
  local cmd, rest = strtrim(input or ""):match("^(%S*)%s*(.-)$")
  cmd = (cmd or ""):lower()

  if cmd == "" or cmd == "panel" then
    togglePanel()
  elseif cmd == "list" then
    print_("Clips (v" .. (TBP_SOUNDPACK_VERSION or "?") .. "):")
    for _, c in ipairs(clips) do
      print_(string.format("  %s  (%.1fs)", c.keyword, c.frames / c.fps))
    end
  elseif cmd == "play" then
    local c = byKeyword[normalize(rest)]
    if c then play(c) else print_("No clip: " .. rest) end
  elseif cmd == "send" then
    local c = byKeyword[normalize(rest)]
    if c then broadcast(c) else print_("No clip: " .. rest) end
  elseif cmd == "mute" then
    db.muted = not db.muted
    if db.muted then stop() end
    print_(db.muted and "Muted." or "Unmuted.")
  elseif cmd == "unlock" then
    unlocked = true
    display:SetSize(256, 256)
    display:EnableMouse(true)
    unlockBg:Show(); unlockLabel:Show(); display:Show()
  elseif cmd == "lock" then
    unlocked = false
    display:EnableMouse(false)
    unlockBg:Hide(); unlockLabel:Hide()
    if not playing then display:Hide() end
  elseif cmd == "scale" then
    local s = tonumber(rest)
    if s and s > 0.1 and s <= 5 then db.scale = s; applyPosition()
    else print_("Usage: /tbp scale 0.5-5") end
  elseif cmd == "reset" then
    db.point = defaults.point; db.scale = 1; applyPosition()
  else
    print_("/tbp [panel] | list | play <kw> | send <kw> | mute | unlock | lock | scale <n> | reset")
  end
end
